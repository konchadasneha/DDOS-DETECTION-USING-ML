import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load dataset (replace 'your_dataset.csv' with your actual dataset path)
df = pd.read_csv('revised_kddcup_dataset.csv')
icmp_data=df[df['protocol_type']=='icmp']
tcp_data=df[df['protocol_type']=='tcp']
udp_data=df[df['protocol_type']=='udp']
icmp_data.shape


tcp_data.shape

udp_data.shape

features=['duration','src_bytes','dst_bytes','land','wrong_fragment','su_attempted','num_outbound_cmds','is_host_login','count','srv_count','serror_rate', 'srv_serror_rate','same_srv_rate','diff_srv_rate',
   'srv_diff_host_rate']

target = 'result'
# Train models for ICMP
x_svm_icmp = icmp_data[features]
y_svm_icmp = icmp_data[target]

x_train_svm_icmp, x_test_svm_icmp, y_train_svm_icmp, y_test_svm_icmp = train_test_split(x_svm_icmp, y_svm_icmp, test_size=0.2)

svm_icmp = SVC()
svm_icmp.fit(x_train_svm_icmp, y_train_svm_icmp)
# Save the model
joblib.dump(svm_icmp, 'models/icmp_svm_model.pkl')

print(type(svm_icmp))
model=joblib.load('models/icmp_svm_model.pkl')
print(type(model))


x_knn_icmp = icmp_data[features]
y_knn_icmp = icmp_data[target]

x_train_knn_icmp, x_test_knn_icmp, y_train_knn_icmp, y_test_knn_icmp = train_test_split(x_knn_icmp, y_knn_icmp, test_size=0.2)


# Train KNN model for ICMP
knn_icmp = KNeighborsClassifier()
knn_icmp.fit(x_train_knn_icmp, y_train_knn_icmp)

# Save the model
joblib.dump(knn_icmp, 'models/icmp_knn_model.pkl')


from sklearn.preprocessing import LabelEncoder
x_linear_icmp = icmp_data[features]
y_linear_icmp = icmp_data[target]

label_encoder = LabelEncoder()
y_linear_icmp_encoded = label_encoder.fit_transform(y_linear_icmp)


x_train_linear_icmp, x_test_linear_icmp, y_train_linear_icmp, y_test_linear_icmp = train_test_split(x_linear_icmp, y_linear_icmp_encoded, test_size=0.2)
linear_regression_icmp = LinearRegression()
linear_regression_icmp.fit(x_train_linear_icmp, y_train_linear_icmp)

# Save the model
joblib.dump(linear_regression_icmp, 'models/icmp_linear_regression_model.pkl')


x_logistic_icmp = icmp_data[features]
y_logistic_icmp = icmp_data[target]

x_train_logistic_icmp, x_test_logistic_icmp, y_train_logistic_icmp, y_test_logistic_icmp = train_test_split(x_logistic_icmp, y_logistic_icmp, test_size=0.2)
# Train Logistic Regression model for ICMP
logistic_regression_icmp = LogisticRegression()
logistic_regression_icmp.fit(x_train_logistic_icmp, y_train_logistic_icmp)

# Save the model
joblib.dump(logistic_regression_icmp, 'models/icmp_logistic_regression_model.pkl')



x_decision_icmp = icmp_data[features]
y_decision_icmp = icmp_data[target]

x_train_decision_icmp, x_test_decision_icmp, y_train_decision_icmp, y_test_decision_icmp = train_test_split(x_decision_icmp, y_decision_icmp, test_size=0.2)
# Train Decision Tree model for ICMP
decision_tree_icmp = DecisionTreeClassifier()
decision_tree_icmp.fit(x_train_decision_icmp, y_train_decision_icmp)

# Save the model
joblib.dump(decision_tree_icmp, 'models/icmp_decision_tree_model.pkl')


x_random_icmp = icmp_data[features]
y_random_icmp = icmp_data[target]

x_train_random_icmp, x_test_random_icmp, y_train_random_icmp, y_test_random_icmp = train_test_split(x_random_icmp, y_random_icmp, test_size=0.2)
# Train Random Forest model for ICMP
random_forest_icmp = RandomForestClassifier()
random_forest_icmp.fit(x_train_random_icmp, y_train_random_icmp)

# Save the model
joblib.dump(random_forest_icmp, 'models/icmp_random_forest_model.pkl')

target = 'result'
# Train models for TCP
x_svm_tcp = tcp_data[features]
y_svm_tcp = tcp_data[target]

x_train_svm_tcp, x_test_svm_tcp, y_train_svm_tcp, y_test_svm_tcp = train_test_split(x_svm_tcp, y_svm_tcp, test_size=0.2)
svm_tcp_model = SVC()
svm_tcp_model.fit(x_train_svm_tcp, y_train_svm_tcp)

# Save the model
joblib.dump(svm_tcp_model, 'models/tcp_svm_model.pkl')

x_knn_tcp = tcp_data[features]
y_knn_tcp = tcp_data[target]

x_train_knn_tcp, x_test_knn_tcp, y_train_knn_tcp, y_test_knn_tcp = train_test_split(x_knn_tcp, y_knn_tcp, test_size=0.2)

# Train KNN model for tcp
knn_tcp = KNeighborsClassifier()
knn_tcp.fit(x_train_knn_tcp, y_train_knn_tcp)

# Save the model
joblib.dump(knn_tcp, 'models/tcp_knn_model.pkl')


x_linear_tcp = tcp_data[features]
y_linear_tcp = tcp_data[target]

label_encoder = LabelEncoder()
y_linear_tcp_encoded = label_encoder.fit_transform(y_linear_tcp)


x_train_linear_tcp, x_test_linear_tcp, y_train_linear_tcp, y_test_linear_tcp = train_test_split(x_linear_tcp, y_linear_tcp_encoded, test_size=0.2)
linear_regression_tcp = LinearRegression()
linear_regression_tcp.fit(x_train_linear_tcp, y_train_linear_tcp)

# Save the model
joblib.dump(linear_regression_tcp, 'models/tcp_linear_regression_model.pkl')

x_logistic_tcp = tcp_data[features]
y_logistic_tcp = tcp_data[target]

x_train_logistic_tcp, x_test_logistic_tcp, y_train_logistic_tcp, y_test_logistic_tcp = train_test_split(x_logistic_tcp, y_logistic_tcp, test_size=0.2)
# Train Logistic Regression model for tcp
logistic_regression_tcp = LogisticRegression()
logistic_regression_tcp.fit(x_train_logistic_tcp, y_train_logistic_tcp)

# Save the model
joblib.dump(logistic_regression_tcp, 'models/tcp_logistic_regression_model.pkl')



x_decision_tcp = tcp_data[features]
y_decision_tcp = tcp_data[target]

x_train_decision_tcp, x_test_decision_tcp, y_train_decision_tcp, y_test_decision_tcp = train_test_split(x_decision_tcp, y_decision_tcp, test_size=0.2)
# Train Decision Tree model for tcp
decision_tree_tcp = DecisionTreeClassifier()
decision_tree_tcp.fit(x_train_decision_tcp, y_train_decision_tcp)

# Save the model
joblib.dump(decision_tree_tcp, 'models/tcp_decision_tree_model.pkl')

x_random_tcp = tcp_data[features]
y_random_tcp = tcp_data[target]

x_train_random_tcp, x_test_random_tcp, y_train_random_tcp, y_test_random_tcp = train_test_split(x_random_tcp, y_random_tcp, test_size=0.2)
# Train Random Forest model for tcp
random_forest_tcp = RandomForestClassifier()
random_forest_tcp.fit(x_train_random_tcp, y_train_random_tcp)

# Save the model
joblib.dump(random_forest_tcp, 'models/tcp_random_forest_model.pkl')

target = 'result'
# Train models for TCP
x_svm_udp = udp_data[features]
y_svm_udp = udp_data[target]

x_train_svm_udp, x_test_svm_udp, y_train_svm_udp, y_test_svm_udp = train_test_split(x_svm_udp, y_svm_udp, test_size=0.2)
svm_udp = SVC()
svm_udp.fit(x_train_svm_udp, y_train_svm_udp)

# Save the model
joblib.dump(svm_udp, 'models/udp_svm_model.pkl')

x_knn_udp = udp_data[features]
y_knn_udp = udp_data[target]

x_train_knn_udp, x_test_knn_udp, y_train_knn_udp, y_test_knn_udp = train_test_split(x_knn_udp, y_knn_udp, test_size=0.2)

# Train KNN model for udp
knn_udp = KNeighborsClassifier()
knn_udp.fit(x_train_knn_udp, y_train_knn_udp)

# Save the model
joblib.dump(knn_udp, 'models/udp_knn_model.pkl')


x_linear_udp = udp_data[features]
y_linear_udp = udp_data[target]

label_encoder = LabelEncoder()
y_linear_udp_encoded = label_encoder.fit_transform(y_linear_udp)


x_train_linear_udp, x_test_linear_udp, y_train_linear_udp, y_test_linear_udp = train_test_split(x_linear_udp, y_linear_udp_encoded, test_size=0.2)
linear_regression_udp = LinearRegression()
linear_regression_udp.fit(x_train_linear_udp, y_train_linear_udp)

# Save the model
joblib.dump(linear_regression_udp, 'models/udp_linear_regression_model.pkl')

x_logistic_udp = udp_data[features]
y_logistic_udp = udp_data[target]

x_train_logistic_udp, x_test_logistic_udp, y_train_logistic_udp, y_test_logistic_udp = train_test_split(x_logistic_udp, y_logistic_udp, test_size=0.2)
# Train Logistic Regression model for udp
logistic_regression_udp = LogisticRegression()
logistic_regression_udp.fit(x_train_logistic_udp, y_train_logistic_udp)

# Save the model
joblib.dump(logistic_regression_udp, 'models/udp_logistic_regression_model.pkl')



x_decision_udp = udp_data[features]
y_decision_udp = udp_data[target]

x_train_decision_udp, x_test_decision_udp, y_train_decision_udp, y_test_decision_udp = train_test_split(x_decision_udp, y_decision_udp, test_size=0.2)
# Train Decision Tree model for udp
decision_tree_udp = DecisionTreeClassifier()
decision_tree_udp.fit(x_train_decision_udp, y_train_decision_udp)

# Save the model
joblib.dump(decision_tree_udp, 'models/udp_decision_tree_model.pkl')

x_random_udp = udp_data[features]
y_random_udp = udp_data[target]

x_train_random_udp, x_test_random_udp, y_train_random_udp, y_test_random_udp = train_test_split(x_random_udp, y_random_udp, test_size=0.2)
# Train Random Forest model for udp
random_forest_udp = RandomForestClassifier()
random_forest_udp.fit(x_train_random_udp, y_train_random_udp)

# Save the model
joblib.dump(random_forest_udp, 'models/udp_random_forest_model.pkl')